This is the README file for the Tin Lizzie NYE 2014 display application

PREREQUISITES:
This program requires the .NET Framework v4.0 & DirectX runtimes to be installed. You may download them at the following links:
 - .NET 4.0 (http://www.microsoft.com/en-us/download/details.aspx?id=17851)
 - DirectX Runtimes (http://www.microsoft.com/en-us/download/details.aspx?id=35)

KEYBOARD SHORTCUTS:
 - (Esc + End) = Ends the software.
 - (F11) = Toggles FullScreen mode.
 - (Ctrl + Shift + D) = Enters Debug Mode and shows Debug info.
 - (Ctrl + Shift + P) = When in Debug Mode, pauses the datapoller.
 - (Ctrl + Shift + Up/Down) = When in Debug Mode, with the datapoller paused, increases or decreases the current coin in value (for testing).

FIRST RUN NOTES:
Before you run the application for the first time, make sure to configure the Settings.ini file.
 - Set the Vertical & Horizontal resolutions to the current screen resolution.
 - Configure the DB connection settings.
 - Customize the CoinInSettings to your promotion.
 - Save and close the Settings file.



