﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace TL_NYE2014
{
    class RainGenerator
    {
        Texture2D _texture;
        float _spawnWidth;
        float _density;

        List<RainDrop> rainDrops = new List<RainDrop>();
        List<Rectangle> sources = new List<Rectangle>();

        float timer;

        Random rand1, rand2;

        public RainGenerator(Texture2D newTexture, float newSpawnWidth, float newDensity)
        {
            _texture = newTexture;
            _spawnWidth = newSpawnWidth;
            _density = newDensity;

            rand1 = new Random();
            rand2 = new Random();

            int count = 0, row = 0, column = 0, spritelimit = 25;

            for (row = 0; row < 5; row++)
            {
                for (column = 0; column < 6; column++)
                {
                    sources.Add(new Rectangle(150 * column, 150 * row, 150, 150));
                    count++;

                    if (count == spritelimit)
                        break;
                }

                if (count == spritelimit)
                    break;
            }
        }

        public void CreateParticle()
        {
           
            rainDrops.Add(new RainDrop(_texture, sources[rand1.Next(0, sources.Count - 1)], new Vector2(
                -50 + (float)rand1.NextDouble() * _spawnWidth, -75),
                new Vector2(0, rand2.Next(5, 8)), (float)rand1.NextDouble()));
        }

        public void Update(GameTime gameTime, GraphicsDevice graphics)
        {
            timer += (float)gameTime.ElapsedGameTime.TotalSeconds;

            while (timer > 0)
            {
                timer -= 1f / _density;
                CreateParticle();
            }

            for (int i = 0; i < rainDrops.Count; i++)
            {
                rainDrops[i].Update();

                if (rainDrops[i].Position.Y > graphics.Viewport.Height + 75)
                {
                    rainDrops.RemoveAt(i);
                    i--;
                }
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            foreach (RainDrop raindrop in rainDrops)
                raindrop.Draw(spriteBatch);
        }

    }

    class RainDrop
    {
        Texture2D _texture;
        Vector2 _position;
        Vector2 _velocity;
        Vector2 _origin;
        Rectangle _source;
        float _rotationSpeed;
        float _rotation;

        public Vector2 Position
        { get { return _position; } }

        public RainDrop(Texture2D texture, Rectangle sourceRectangle, Vector2 position, Vector2 velocity, float rotationSpeed)
        {
            _texture = texture;
            _position = position;
            _velocity = velocity;
            _source = sourceRectangle;
            _rotationSpeed = rotationSpeed;
            _origin = new Vector2(_source.Width / 2, _source.Height / 2);
        }

        public void Update()
        {
            _position += _velocity;
            _rotation += _rotationSpeed / 100f;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(_texture, _position, _source, Color.White, _rotation, _origin, 1.0f, SpriteEffects.None, 0.5f);
        }
    }
}
