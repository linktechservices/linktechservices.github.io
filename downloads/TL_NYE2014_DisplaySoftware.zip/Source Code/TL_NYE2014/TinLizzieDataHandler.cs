﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using System.Data.SqlClient;

class TinLizzieDataHandler
{
    const long _MINIMUM_COIN_IN = 0;
    const long _MAXIMUM_COIN_IN = 1000000000L; //$10,000,000.00
    const long _MAXIMUM_INCREMENT_LIMIT = 10000000; //safety for 'runaway' meters or mistakes ~$100,000.00


    //Private Vars
    private UInt64 _coinIn, _primer, _coinInToNextLevel;
    private float _winnerPercent, _primerPercent;
    private uint _levelsNeededToWin, _totalWinners, _totalCelebratedWinners;
    private int _currentLevel, _hRes, _vRes;
    private string _sqlErrorMsg, _IOErrorMsg, _connStr; 
    private IniParser _iniParser;
    private System.Timers.Timer _timer;
    private bool _isCoinInVarDirty, _isCelebratedWinnerVarDirty, _startFullScreen;

    //Public Vars
    public bool Paused { get; set; }
    
    public UInt64 CoinIn { get { return _coinIn; } }
    public UInt64 Primer { get { return _primer; } }
    public UInt64 CoinInToNextLevel { get { return _coinInToNextLevel; } }
    public int CurrentLevel { get { return _currentLevel; } }
    public float WinnerPercent { get { return _winnerPercent; } }
    public float PrimerPercent { get { return _primerPercent; } }
    public uint TotalWinners { get { return _totalWinners; } }
    public int HorizontalResolution { get { return _hRes; } }
    public int VerticalResolution { get { return _vRes; } }
    public bool StartFullScreen { get { return _startFullScreen; } }

    public uint TotalCelebratedWinners 
    { 
        get { return _totalCelebratedWinners; }
        set
        {
            //sanity check
            if (value > _totalWinners)
                _totalCelebratedWinners = _totalWinners;
            else
                _totalCelebratedWinners = value;

            _isCelebratedWinnerVarDirty = true;
        }
    }

    public string ErrorMessages
    {
        get
        {
            string output = "";

            output += @"[LastIOError]: ";
            if (_IOErrorMsg == null)
                output += @"<none> ";
            else
                output += _IOErrorMsg;

            output += "\n\n";

            output += @"[LastSQLError]: ";
            if (_sqlErrorMsg == null)
                output += @"<none> ";
            else
                output += _sqlErrorMsg;

            return output;
        }
    }

    public bool TimeToCelebrate
    {
        get { return _totalWinners > TotalCelebratedWinners; }
    }
 
    /// <summary>
    /// Creates a new instance of the TinLizzieDataHandler
    /// </summary>
    public TinLizzieDataHandler(uint LevelsNeededToWin)
    {
        _winnerPercent = _primerPercent = _coinIn = _primer = _coinInToNextLevel = 0;
        _currentLevel = -1;
        _isCoinInVarDirty = true;
        _levelsNeededToWin = LevelsNeededToWin;
    }


    public void Initialize(string filepath)
    {
        _iniParser = new IniParser(filepath);
        
        if (!System.IO.File.Exists(filepath))
            CreateDefaultConfigFile();
        if (System.IO.File.Exists(filepath))
            LoadConfigFile();

        _timer.Elapsed += new System.Timers.ElapsedEventHandler(TimerTick);
        _timer.Enabled = true;

        TimerTick(null, null);
        this.Update(null);

        
    }


    public void CreateDefaultConfigFile()
    {
        try
        {
            _iniParser.WriteSetting("CoinInSettings", "PrimerInPennies", "10000000");
            _iniParser.WriteSetting("CoinInSettings", "AmtNeededToWinInPennies", "500000");
            _iniParser.WriteSetting("DataSettings", "Server", "tinoasis");
            _iniParser.WriteSetting("DataSettings", "Database", "WinOasis");
            _iniParser.WriteSetting("DataSettings", "UserID", "sa");
            _iniParser.WriteSetting("DataSettings", "Password", "lizzietin");
            _iniParser.WriteSetting("DataSettings", "DBPollingFrequencyInSeconds", "60");
            _iniParser.WriteSetting("GraphicSettings", "HorizontalResolution", "1366");
            _iniParser.WriteSetting("GraphicSettings", "VerticalResolution", "768");
            _iniParser.WriteSetting("GraphicSettings", "StartFullscreen", "true");
            _IOErrorMsg = "";
        }
        catch (Exception ex)
        {
            _IOErrorMsg = ex.Message;
        }
    }

    public void LoadConfigFile()
    {
        try
        {
            _primer = Convert.ToUInt64(_iniParser.ReadSetting("CoinInSettings", "PrimerInPennies"));
            _coinInToNextLevel = Convert.ToUInt64(_iniParser.ReadSetting("CoinInSettings", "AmtNeededToWinInPennies")) / _levelsNeededToWin;
            _timer = new System.Timers.Timer(Convert.ToDouble(_iniParser.ReadSetting("DataSettings", "DBPollingFrequencyInSeconds")) * 1000);
            _hRes = Convert.ToInt32(_iniParser.ReadSetting("GraphicSettings", "HorizontalResolution"));
            _vRes = Convert.ToInt32(_iniParser.ReadSetting("GraphicSettings", "VerticalResolution"));
            _startFullScreen = Convert.ToBoolean(_iniParser.ReadSetting("GraphicSettings", "StartFullScreen"));

            SqlConnectionStringBuilder sb = new SqlConnectionStringBuilder();
            sb.DataSource = _iniParser.ReadSetting("DataSettings", "Server");
            sb.InitialCatalog = _iniParser.ReadSetting("DataSettings", "Database");
            sb.UserID = _iniParser.ReadSetting("DataSettings", "UserID");
            sb.Password = _iniParser.ReadSetting("DataSettings", "Password");
            sb.PersistSecurityInfo = true;
            sb.IntegratedSecurity = false;

            _connStr = sb.ConnectionString;

            _IOErrorMsg = "";
        }
        catch (Exception ex)
        {
            _IOErrorMsg = ex.Message;
        }
    }

    public void Update(GameTime gameTime)
    {
        if (_isCoinInVarDirty || _isCelebratedWinnerVarDirty) //run through the math only if vars changed
        {
            if (IsPrimed()) //First check to make sure we have hit our primer value
            {
                _winnerPercent = (float)(CoinIn - Primer) / (float)CoinInToNextLevel;
                _totalWinners = (uint)(_winnerPercent / (float)_levelsNeededToWin);
                _currentLevel = (int)((_winnerPercent - 1.0f) % (float)_levelsNeededToWin);

                if (_isCelebratedWinnerVarDirty)//where a winner was celebrated but coinin may not have incremented enough to reset the _currentLevel variable.
                {
                    if (_currentLevel == _levelsNeededToWin - 1 && _totalWinners == TotalCelebratedWinners)
                        _currentLevel = -1;
                    else
                        _isCelebratedWinnerVarDirty = false;
                }
            }
            else
            {
                _winnerPercent = _totalWinners = 0;
            }

            _isCoinInVarDirty = false;
        }
    }

    public bool IsPrimed()
    {
        if (_coinIn >= _primer) //means we have hit our primer value
        {
            _primerPercent = 1.0f;
            return true;
        }
        else
        {
            _primerPercent = (float)((double)CoinIn / (double)Primer);
            return false;
        }
    }

    public void HandleInput(GameTime gameTime, KeyboardState currentState, KeyboardState priorState)
    {
        if (Paused == true &&
            (currentState.IsKeyDown(Keys.RightShift) || currentState.IsKeyDown(Keys.LeftShift)) &&
            (currentState.IsKeyDown(Keys.LeftControl) || currentState.IsKeyDown(Keys.RightControl)) &&
            currentState.IsKeyDown(Keys.Up))
        {
            IncreaseCoinIn(10000);
        }

        if ((currentState.IsKeyDown(Keys.RightShift) || currentState.IsKeyDown(Keys.LeftShift)) &&
            (currentState.IsKeyDown(Keys.LeftControl) || currentState.IsKeyDown(Keys.RightControl)) &&
            currentState.IsKeyDown(Keys.P) && priorState.IsKeyUp(Keys.P))
        {
            Paused = !Paused;
        }
    }

    private void IncreaseCoinIn(int value)
    {
        if (value > 0 && value <= _MAXIMUM_INCREMENT_LIMIT)
        {
            UInt64 newvalue = CoinIn + Convert.ToUInt64(value);
            SetCoinIn(newvalue);
        }
    }

    private void SetCoinIn(UInt64 value)
    {
        if ((Math.Max(value,CoinIn) - Math.Min(value, CoinIn) <= _MAXIMUM_INCREMENT_LIMIT || CoinIn == 0))
        {
            if (value > _MAXIMUM_COIN_IN)
                _coinIn = _MAXIMUM_COIN_IN;
            else if (value < _MINIMUM_COIN_IN)
                _coinIn = _MINIMUM_COIN_IN;
            else
                _coinIn = value;

            _isCoinInVarDirty = true;
        }
    }

    private void TimerTick(object sender, System.Timers.ElapsedEventArgs e)
    {
        if (!Paused)
        {

            string SQLString = "SELECT TOP 1 CoinIn FROM LiveValuesForDisplaySoftware WHERE ID = '33b67527-b2cd-4a2a-bc8a-7d75a10ea3c0' ORDER BY EndTime DESC";

            UInt64 newCoinIn = 0;
            SqlConnection connection;
            SqlCommand cmd;

            try
            {
                connection = new SqlConnection(_connStr);
                cmd = new SqlCommand(SQLString, connection);

                connection.Open();
                //SqlDataReader reader = cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    newCoinIn = Convert.ToUInt64(reader["CoinIn"]);
                }

                reader.Close();
                _sqlErrorMsg = "";

            }
            catch (Exception ex) 
            {
                _sqlErrorMsg = ex.Message;
            }
            finally
            {
                if (newCoinIn > 0 && newCoinIn != CoinIn)
                    SetCoinIn(newCoinIn);
            }
        }
    }

}

