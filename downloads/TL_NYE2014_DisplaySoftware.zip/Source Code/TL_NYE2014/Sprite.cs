﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace TL_NYE2014
{
    class Sprite
    {
        //public variables
        public Vector2 CurrentPosition = Vector2.Zero;

        public Rectangle Size;
        public float Angle = 0.0f;
        public string AssetName;
        public float Opacity = 1.0f;

        private Color tint = Color.White;
        public Color Tint { get { return tint; } set { tint = value; } }

        //private variables
        private Texture2D spriteTexture;
        public Texture2D SpriteTexture
        {
            get { return spriteTexture; }
        }

        private Vector2 startingPosition = Vector2.Zero;
        public Vector2 StartingPosition
        {
            get { return startingPosition; }
            set
            {
                startingPosition = value;
                CurrentPosition = startingPosition;
            }
        }

        private float scale = 1.0f;
        public float Scale
        {
            get { return scale; }
            set
            {
                scale = value;
                Size = new Rectangle(0, 0, (int)(Source.Width * Scale), (int)(Source.Height * Scale));
            }
        }

        private Origin spriteOrigin = Origin.UpperLeft;
        private Vector2 origin = Vector2.Zero;
        public Origin SpriteOrigin
        {
            get { return spriteOrigin; }
            set
            {
                spriteOrigin = value;
                switch (spriteOrigin)
                {
                    case Origin.UpperLeft:
                        origin = Vector2.Zero;
                        break;
                    case Origin.UpperRight:
                        origin = new Vector2((float)spriteTexture.Width, 0.0f);
                        break;
                    case Origin.LowerLeft:
                        origin = new Vector2(0.0f, (float)spriteTexture.Height);
                        break;
                    case Origin.LowerRight:
                        origin = new Vector2((float)spriteTexture.Width, (float)spriteTexture.Height);
                        break;
                    case Origin.Center:
                        origin = new Vector2((float)spriteTexture.Width * 0.5f, (float)spriteTexture.Height * 0.5f);
                        break;
                }

            }
        }

        public enum Origin
        {
            UpperLeft,
            UpperRight,
            LowerLeft,
            LowerRight,
            Center
        }

        private Rectangle source;
        public Rectangle Source
        {
            get { return source; }
            set
            {
                source = value;
                Size = new Rectangle(0, 0, (int)(source.Width * Scale), (int)(source.Height * Scale));
            }
        }

        public void LoadContent(ContentManager contentManager, string assetName)
        {
            spriteTexture = contentManager.Load<Texture2D>(assetName);
            AssetName = assetName;
            Source = new Rectangle(0, 0, spriteTexture.Width, spriteTexture.Height);
            Size = new Rectangle(0, 0, (int)(spriteTexture.Width * Scale), (int)(spriteTexture.Height * Scale));
        }

        public virtual void Update(GameTime gameTime, Vector2 speed, Vector2 direction)
        {
            CurrentPosition += direction * speed * (float)gameTime.ElapsedGameTime.TotalSeconds;
        }
        
        public virtual void Draw(SpriteBatch spriteBatch)
        {
             spriteBatch.Draw(spriteTexture, CurrentPosition, Source , new Color(Tint.R, Tint.G, Tint.B, (float)MathHelper.Clamp(Opacity, 0.0f, 1.0f)),
                Angle, origin, Scale, SpriteEffects.None, 0);
        }

    }
}
