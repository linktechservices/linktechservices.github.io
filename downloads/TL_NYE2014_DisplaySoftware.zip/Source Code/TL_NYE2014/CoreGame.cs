using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using XNAUtilities;

namespace TL_NYE2014
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class CoreGame : Microsoft.Xna.Framework.Game
    {
        int RES_WIDTH, RES_HEIGHT;

        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        bool IsFullScreen, winnerFadeOut;

        WinnerScreen winnerScreen = new WinnerScreen();
        RainGenerator moneyRain;
        FadeScreen fadeScreen;

        KeyboardState currentKeyboardState = Keyboard.GetState();
        KeyboardState previousKeyboardState = Keyboard.GetState();

        Texture2D backgroundTexture;
        Texture2D WinnersBackground;

        Song winnerSong;
        

        SpriteFont debugFont;
        bool debugMode = false;
        TinLizzieDataHandler data = new TinLizzieDataHandler(20);

        List<Glow> glowList = new List<Glow>();
        List<Glow> glow4pack = new List<Glow>();

        private GameState _gameState = GameState.Normal;
        public enum GameState
        {
            Normal,
            WaitingToAdvance
        }

        private GameScreen _activeScreen = GameScreen.MainScreen;
        public enum GameScreen
        {
            MainScreen,
            WinnerScreen
        }


        public CoreGame()
        {
            graphics = new GraphicsDeviceManager(this);
            graphics.PreferredBackBufferWidth = RES_WIDTH = GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Width;
            graphics.PreferredBackBufferHeight = RES_HEIGHT = GraphicsAdapter.DefaultAdapter.CurrentDisplayMode.Height;

            Content.RootDirectory = "Content";   
        }

        protected override void Initialize()
        {
            string filepath = System.Windows.Forms.Application.StartupPath;
            filepath += "\\Settings.ini";

            data.Initialize(filepath);

            graphics.PreferredBackBufferHeight = RES_HEIGHT = data.VerticalResolution; //vertical resolution
            graphics.PreferredBackBufferWidth = RES_WIDTH = data.HorizontalResolution; //horizontal resolution
            graphics.ApplyChanges();

            if (data.StartFullScreen)
                ToggleFullScreen();

            base.Initialize();

        }

        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            Rectangle FullScreen = GraphicUtilities.FullscreenRectangle(graphics);

            fadeScreen = new FadeScreen(GraphicsDevice);

            winnerScreen.LoadContent(Content, FullScreen);
            moneyRain = new RainGenerator(Content.Load<Texture2D>(@"Sprites\MoneySheet"), graphics.GraphicsDevice.Viewport.Width * 1.1f, 100);

            backgroundTexture = Content.Load<Texture2D>("Background1");
            WinnersBackground = Content.Load<Texture2D>("Background2");

            //winnerSong = Content.Load<SoundEffect>(@"Audio\Celebration");
            //winnerSongInstance = winnerSong.CreateInstance();
            winnerSong = Content.Load<Song>(@"Audio\Celebration");

            debugFont = Content.Load<SpriteFont>(@"Fonts\Arial Bold");
            //debugFont = Content.Load<SpriteFont>(@"Arial");


            //The following are for 1024 x 768 resolutions
            //float HORIZONTAL_OFFSET = 132;
            //float VERTICAL_OFFSET = 192;
            //float HORIZONTAL_SPACING = 190;
            //float VERTICAL_SPACING = 140;

            float HORIZONTAL_OFFSET = (float)RES_WIDTH * 0.12890625f;
            float VERTICAL_OFFSET = (float)RES_HEIGHT * 0.25f;
            float HORIZONTAL_SPACING = (float)RES_WIDTH * 0.185546875f;
            float VERTICAL_SPACING = (float)RES_HEIGHT * 0.18229166666666666666666666666667f;

            for (int r = 0; r < 4; r++)
            {
                for (int c = 0; c < 5; c++)
                {
                    Glow g = new Glow();
                    g.LoadContent(Content, FullScreen);
                    g.StartingPosition = new Vector2(HORIZONTAL_OFFSET + (float)c * HORIZONTAL_SPACING, VERTICAL_OFFSET + (float)r * VERTICAL_SPACING);
                    g.Tint = new Color(0.0f, 1.0f, 0.0f);
                    glowList.Add(g);
                }
            }

            //The following are for 1024 x 768 resolutions
            //HORIZONTAL_OFFSET = 353;
            //VERTICAL_OFFSET = 65;
            //HORIZONTAL_SPACING = 105;

            HORIZONTAL_OFFSET = (float)RES_WIDTH * 0.3447265625f;
            VERTICAL_OFFSET = (float)RES_HEIGHT * 0.08463541666666666666666666666667f;
            HORIZONTAL_SPACING = (float)RES_WIDTH * 0.1025390625f;

            for (int i = 0; i < 4; i++)
            {
                Glow g = new Glow();
                g.LoadContent(Content, FullScreen);
                g.StartingPosition = new Vector2(HORIZONTAL_OFFSET + (float)i * HORIZONTAL_SPACING, VERTICAL_OFFSET);
                g.Tint = Color.Red;
                glow4pack.Add(g);
            }
           
        }


        protected override void Update(GameTime gameTime)
        {

            //Handle key presses
            HandleInput(gameTime);
            
            data.Update(gameTime);


            if (_fadeMusic)
                FadeOutMusic();
            
            if (_activeScreen == GameScreen.MainScreen)
                UpdateMainScreen(gameTime);
            else if (_activeScreen == GameScreen.WinnerScreen)
                UpdateWinnerScreen(gameTime);            

            base.Update(gameTime);
        }

        private void UpdateMainScreen(GameTime gameTime)
        {
            int numberofglows = 0;

            //adjust the number of glows to a full screen if it is a back to back hit.
            if (data.TimeToCelebrate)
                numberofglows = 19;
            else
                numberofglows = data.CurrentLevel;

            //update our main field glows
            for (int i = 0; i < glowList.Count; i++)
            {
                if (numberofglows >= i && glowList[i].CurrentState == Glow.State.Invisible)
                    glowList[i].ChangeState(Glow.State.FadingIn);
                //else
                //    glowList[i].ResetToStart();

                glowList[i].Update(gameTime);
            }

            //update our top field glows.
            int glows = (numberofglows + 1) / 5;
            for (int i = 0; i < glow4pack.Count; i++)
            {
                if (glows - 1 >= i && glow4pack[i].CurrentState == Glow.State.Invisible)
                    glow4pack[i].ChangeState(Glow.State.FadingIn);
                //else
                //    glow4pack[i].ResetToStart();

                glow4pack[i].Update(gameTime);
            }


            //Check if we need to celebrate a winner
            if (data.TimeToCelebrate && _gameState == GameState.Normal && glow4pack[3].CurrentState == Glow.State.Visible && glowList[19].CurrentState == Glow.State.Visible)
            {
                data.TotalCelebratedWinners++;
                _gameState = GameState.WaitingToAdvance;
                data.Paused = true;
                _fadeMusic = false;
                winnerFadeOut = false;
                MediaPlayer.Volume = 0.95f;
                MediaPlayer.Play(winnerSong);
               
                //winnerSong.Play();
            }

            // If we are ready to advance to the winner screen...
            if (_gameState == GameState.WaitingToAdvance)
            {
                fadeScreen.CurrentFadeState = FadeScreen.FadeState.FadeInOut;

                fadeScreen.Update(gameTime);

                if (fadeScreen.IsFinished && fadeScreen.Opacity == 255)
                {
                    _activeScreen = GameScreen.WinnerScreen;
                    _gameState = GameState.Normal;

                    foreach (Glow g in glowList)
                        g.ResetToStart();

                    foreach (Glow g in glow4pack)
                        g.ResetToStart();
                }
            }
            else if (_gameState == GameState.Normal)
                fadeScreen.Update(gameTime);


        }

        private void UpdateWinnerScreen(GameTime gameTime)
        {
            moneyRain.Update(gameTime, GraphicsDevice);

            winnerScreen.Update(gameTime);

            if (MediaPlayer.State == MediaState.Stopped)
            {
                MediaPlayer.Play(winnerSong);
                winnerFadeOut = true;
            }
            else if (winnerFadeOut)
            {
                fadeScreen.CurrentFadeState = FadeScreen.FadeState.FadeInOut;

                fadeScreen.Update(gameTime);

                if (fadeScreen.IsFinished && fadeScreen.Opacity == 255)
                {
                    _activeScreen = GameScreen.MainScreen;
                    _gameState = GameState.Normal;
                    _fadeMusic = true;
                    data.Paused = false;
                }
            }
            else if (_gameState == GameState.Normal)
                fadeScreen.Update(gameTime);
        }

        private bool _fadeMusic = false;
        private void FadeOutMusic()
        {
            float speed = 0.01f;

            if (MediaPlayer.Volume > speed)
                MediaPlayer.Volume -= speed;
            else
            {
                _fadeMusic = false;
                MediaPlayer.Stop();
            }

        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);
            
            spriteBatch.Begin(SpriteSortMode.Immediate, BlendState.AlphaBlend);

            if (_activeScreen == GameScreen.MainScreen)
                DrawMainScreen(gameTime);
            else if (_activeScreen == GameScreen.WinnerScreen)
                DrawWinnerScreen(gameTime);

            if (debugMode)
            {
                DrawDebugInfo(gameTime);
            }

            spriteBatch.End();

            base.Draw(gameTime);
        }

        private void DrawMainScreen(GameTime gameTime)
        {
            //Draw the background
            spriteBatch.Draw(backgroundTexture, GraphicUtilities.FullscreenRectangle(graphics), Color.White);

            foreach (Glow g in glowList)
                g.Draw(spriteBatch);

            foreach (Glow g in glow4pack)
                g.Draw(spriteBatch);

            fadeScreen.Draw(spriteBatch);
        }

        private void DrawWinnerScreen(GameTime gameTime)
        {
            //Draw the background
            spriteBatch.Draw(WinnersBackground, GraphicUtilities.FullscreenRectangle(graphics), Color.White);

            moneyRain.Draw(spriteBatch);

            winnerScreen.Draw(spriteBatch);

            fadeScreen.Draw(spriteBatch);
        }

        private void DrawDebugInfo(GameTime gameTime)
        {
            float scale = 1f;
            Vector2 startingPosition = new Vector2(10, 10);
            int qty = 0;
            Color debugColor = Color.White;

            spriteBatch.DrawString(debugFont, "CoinIn: " + String.Format("{0:C}", ((float)data.CoinIn / 100f)),
                new Vector2(startingPosition.X, startingPosition.Y + 30 * scale * qty), debugColor,
                0, Vector2.Zero, scale, SpriteEffects.None, 0.5f);

            qty++;
            spriteBatch.DrawString(debugFont, "PrimerAmt: " + data.Primer.ToString(),
                new Vector2(startingPosition.X, startingPosition.Y + 30 * scale * qty), debugColor,
            0, Vector2.Zero, scale, SpriteEffects.None, 0.5f);

            qty++;
            spriteBatch.DrawString(debugFont, "PrimerVar: " + String.Format("{0:P}", data.PrimerPercent),
                new Vector2(startingPosition.X, startingPosition.Y + 30 * scale * qty), debugColor,
                0, Vector2.Zero, scale, SpriteEffects.None, 0.5f);

            qty++;
            spriteBatch.DrawString(debugFont, "CoinInToNextCoin: " + data.CoinInToNextLevel.ToString(),
                new Vector2(startingPosition.X, startingPosition.Y + 30 * scale * qty), debugColor,
            0, Vector2.Zero, scale, SpriteEffects.None, 0.5f);

            qty++;
            spriteBatch.DrawString(debugFont, "WinnerVar: " + String.Format("{0:F3}", data.WinnerPercent),
                new Vector2(startingPosition.X, startingPosition.Y + 30 * scale * qty), debugColor,
            0, Vector2.Zero, scale, SpriteEffects.None, 0.5f);

            qty++;
            spriteBatch.DrawString(debugFont, "TotalWinners: " + data.TotalWinners.ToString(),
                new Vector2(startingPosition.X, startingPosition.Y + 30 * scale * qty), debugColor,
            0, Vector2.Zero, scale, SpriteEffects.None, 0.5f);

            qty++;
            spriteBatch.DrawString(debugFont, "CelebratedWinners: " + data.TotalCelebratedWinners.ToString(),
                new Vector2(startingPosition.X, startingPosition.Y + 30 * scale * qty), debugColor,
            0, Vector2.Zero, scale, SpriteEffects.None, 0.5f);

            qty++;
            spriteBatch.DrawString(debugFont, "CurrentLevel: " + data.CurrentLevel.ToString(),
                new Vector2(startingPosition.X, startingPosition.Y + 30 * scale * qty), debugColor,
            0, Vector2.Zero, scale, SpriteEffects.None, 0.5f);

            qty++;
            spriteBatch.DrawString(debugFont, "DataPollerPaused: " + data.Paused.ToString(),
                new Vector2(startingPosition.X, startingPosition.Y + 30 * scale * qty), debugColor,
            0, Vector2.Zero, scale, SpriteEffects.None, 0.5f);

            float errormsgscale = .75f * scale;
            spriteBatch.DrawString(debugFont, GraphicUtilities.WrapText(debugFont, data.ErrorMessages, (graphics.GraphicsDevice.Viewport.Width / 2) * 1 / errormsgscale),
                new Vector2(graphics.GraphicsDevice.Viewport.Width * 0.5f, startingPosition.Y), debugColor,
                0, Vector2.Zero, errormsgscale, SpriteEffects.None, 0.5f);
        }

        private void HandleInput(GameTime gameTime)
        {
            currentKeyboardState = Keyboard.GetState();

            if (currentKeyboardState.IsKeyDown(Keys.Escape) && currentKeyboardState.IsKeyDown(Keys.End))
            {
                Exit();
            }
            
            else if ((currentKeyboardState.IsKeyDown(Keys.F11) && previousKeyboardState.IsKeyUp(Keys.F11)))
            {
                ToggleFullScreen();
            }
            
            else if (currentKeyboardState.IsKeyDown(Keys.D) && 
                (currentKeyboardState.IsKeyDown(Keys.LeftControl) || currentKeyboardState.IsKeyDown(Keys.RightControl)) && 
                (currentKeyboardState.IsKeyDown(Keys.LeftShift) || currentKeyboardState.IsKeyDown(Keys.RightShift)) && 
                previousKeyboardState.IsKeyUp(Keys.D))
            {
                debugMode = !debugMode;
            }

            if (debugMode && _activeScreen == GameScreen.MainScreen)
                data.HandleInput(gameTime, currentKeyboardState, previousKeyboardState);

            previousKeyboardState = currentKeyboardState;
        }

        private void ToggleFullScreen()
        {
            IsFullScreen = !IsFullScreen;

            graphics.IsFullScreen = Window.IsBorderless = IsFullScreen;

            Window.Position = new Point(0, 0);
            graphics.PreferredBackBufferWidth = RES_WIDTH;
            graphics.PreferredBackBufferHeight = RES_HEIGHT;
            graphics.ApplyChanges();
        }


    }
}
