﻿#region Using Statements
using System;
using System.Collections.Generic;
using System.Linq;
#endregion

namespace TL_NYE2014
{
#if WINDOWS || LINUX || WINDOWS8
    /// <summary>
    /// The main class.
    /// </summary>
    public static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
#if DEBUG
            using (var game = new CoreGame())
                game.Run();
#else
            CoreGame game = new CoreGame();
            try { game.Run(); }
            catch (Exception ex)
            {
                LogWriter errlog = new LogWriter(LogWriter.FileNameStyles.LogTypeMMDDYY, "Error", ".log");
                errlog.Write(ex, true, true);

                System.Windows.Forms.MessageBox.Show("An error has been encountered and this program has been terminated, please refer to the logs for more information.", "Error");
            }
            finally
            {
                if (game != null)
                    game.Dispose();
            }
#endif
        }
    }
#endif
}
