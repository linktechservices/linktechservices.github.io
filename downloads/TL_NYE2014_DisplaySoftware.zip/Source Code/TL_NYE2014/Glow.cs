﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace TL_NYE2014
{
    class Glow : Sprite
    {
        const string ASSETNAME = @"Sprites\WhiteGlow";
        const int MOVE_LEFT = -1;
        const int MOVE_RIGHT = 1;
        const int MOVE_DOWN = 1;
        const int MOVE_UP = -1;
        const float ENTRY_SPEED = 0.05f;
        const float MAXIMUM_SCALE = 10.0f;
        const float MINIMUM_SCALE = 0.0f;

        public enum State
        {
            Visible,
            Invisible,
            Moving,
            FadingIn
        }

        private State mCurrentState = State.Invisible;
        public State CurrentState
        {
            get { return mCurrentState; }
        }

        private State mPriorState;
        public State PriorState
        {
            get {return mPriorState;}
        }

        Vector2 mDirection = Vector2.Zero;
        Vector2 mSpeed = Vector2.Zero;

        float fadeSpeed;
        float rotationSpeed;
        float scaleSpeed;

        float mScale;

        Rectangle screenBoundary;

        public void LoadContent(ContentManager content, Rectangle boundary)
        {
            base.LoadContent(content, ASSETNAME);

            CurrentPosition = Vector2.Zero;
            SpriteOrigin = Origin.Center;

            ResetToStart(); //start invisible

            //we want the final glow to be 76 pixels so....
            mScale = 125.0f / (float)this.SpriteTexture.Height;

            //calculate speeds based on ENTRY_SPEED constant
            fadeSpeed = ENTRY_SPEED * .3f;
            rotationSpeed = ENTRY_SPEED * (float)Math.PI * .05f;
            scaleSpeed = ENTRY_SPEED * mScale * .3f;



            screenBoundary = boundary;

        }

        public void Update(GameTime gameTime)
        {
            if (CurrentState == State.FadingIn)
            {
                FadeIn();
                CurrentPosition += mDirection * mSpeed * (float)gameTime.ElapsedGameTime.TotalSeconds;
            }
            else if (CurrentState == State.Moving)
            {
                if (PriorState == State.Visible)
                {
                    _startTime = gameTime.TotalGameTime.TotalSeconds;
                    ChangeState(State.Moving);
                }
                
                double deltaT = gameTime.TotalGameTime.TotalSeconds - _startTime;
                FallDown(deltaT);

            }
            Angle += rotationSpeed;
            //base.Update(gameTime, mSpeed, mDirection);

        }

        public void ResetToStart()
        {
            Opacity = 0.0f;
            Angle = 0.0f;
            Scale = 0.0f;

            mSpeed = Vector2.Zero;
            mDirection = Vector2.Zero;

            CurrentPosition = StartingPosition;
            ChangeState(State.Invisible);
        }

        private void FadeIn()
        {
            if (Opacity <= 1.0f)
            {
                Opacity += fadeSpeed;
                Scale += scaleSpeed;
            }
            else
            {
                ChangeState(State.Visible);
            }
        }

        private Vector2 _gravity = new Vector2(0f, 9.8f);
        private double _startTime;

        private void FallDown(double deltaT)
        {
            if (CurrentPosition.Y - (Size.Height / 2) < screenBoundary.Height)
            {
                //float dt = (float)deltaT;
                mDirection.Y = MOVE_DOWN;
                CurrentPosition += mSpeed * (float)deltaT + 0.5f * _gravity * (float)deltaT * (float)deltaT;
                mSpeed = _gravity * (float)deltaT;
            }
            else
            {
                ResetToStart();
            }
        }

        public void ChangeState(State newState)
        {
            mPriorState = mCurrentState;
            mCurrentState = newState;
        }
    }
}
