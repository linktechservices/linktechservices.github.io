﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace TL_NYE2014
{
    class WinnerScreen
    {
        Texture2D _WinnerText;
        Texture2D _Logo;

        Vector2 _WinnerTextPosition;
        Vector2 _WinnerTextOrigin;
        Vector2 _MPLogoPosition;
        Vector2 _MPLogoOrigin;
        Vector2 _Scale;
        Vector2 _CentralPosition;
        Color _tint = Color.White;

        float _rotation = -0.15f;

        public WinnerScreen() { }

        public void LoadContent(ContentManager content, Rectangle fullScreenRectangle)
        {
            _WinnerText = content.Load<Texture2D>(@"Sprites\WinnerText");
            _WinnerTextOrigin = new Vector2(_WinnerText.Width / 2, _WinnerText.Height / 2);
            _WinnerTextPosition = _CentralPosition = new Vector2(fullScreenRectangle.Width / 2, fullScreenRectangle.Height / 2);

            _Logo = content.Load<Texture2D>(@"Sprites\NewYears");
            _MPLogoOrigin = new Vector2(_Logo.Width / 2, _Logo.Height / 2);
            _MPLogoPosition = new Vector2(fullScreenRectangle.Width / 2, 112);

            _Scale = new Vector2((float)fullScreenRectangle.Width / 1024f, (float)fullScreenRectangle.Height / 768f);
        }

        public void Update(GameTime gameTime)
        {
            float verticalmovement = 50;
            float rotationmovement = 0.15f;

            _WinnerTextPosition.Y = Pulsate(gameTime, 10, _CentralPosition.Y - verticalmovement, _CentralPosition.Y + verticalmovement);
            _rotation = Pulsate(gameTime, 5, -0.15f, .20f);
            _tint.B = (byte)Pulsate(gameTime, 30, 50, 255);
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(_Logo, _MPLogoPosition, null, Color.White, 0.0f, _MPLogoOrigin, _Scale, SpriteEffects.None, 0.5f);

            spriteBatch.Draw(_WinnerText, _WinnerTextPosition, null, _tint, _rotation, _WinnerTextOrigin, _Scale, SpriteEffects.None, 0.5f);
        }

        private static float Pulsate(GameTime gameTime, float speed, float min, float max)
        {
            double time = gameTime.TotalGameTime.TotalSeconds * speed;

            return min + ((float)Math.Sin(time) + 1) / 2 * (max - min);
        }

    }
}
