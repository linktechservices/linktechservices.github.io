using System;
using System.Runtime.InteropServices;
using System.Text;

/// <summary>
/// Class to help with the reading and writing of INI configuration files.
/// </summary>
public class IniParser
{
    public string IniFilePath;

    [DllImport("kernel32")]
    private static extern long WritePrivateProfileString(string section,
        string key, string val, string filePath);

    [DllImport("kernel32")]
    private static extern int GetPrivateProfileString(string section,
        string key, string def, StringBuilder retVal, int size, string filePath);

    /// <summary>
    /// Empty constructor for initialization.
    /// </summary>
    public IniParser()
    {
    }

    /// <summary>
    /// Initializes a new instance of the IniParser class.
    /// </summary>
    /// <param name="FilePath">Full file path to the INI file.</param>
    public IniParser(string FilePath)
    {
        IniFilePath = FilePath;
    }

    /// <summary>
    /// Write setting to INI file.
    /// </summary>
    /// <param name="Section">Section name containing setting to write.</param>
    /// <param name="Setting">Setting name to write or change.</param>
    /// <param name="Value">Value to write.</param>
    public void WriteSetting(string SectionName, string SettingName, string Value)
    {
        WritePrivateProfileString(SectionName, SettingName, Value, this.IniFilePath);
    }

    /// <summary>
    /// Returns the value of the specified setting.
    /// </summary>
    /// <param name="Section">Section name containing setting to read.</param>
    /// <param name="Key">Setting name to read value from.</param>
    public string ReadSetting(string SectionName, string SettingName)
    {
        StringBuilder sbOut = new StringBuilder(500);
        GetPrivateProfileString(SectionName, SettingName, "", sbOut, 500, this.IniFilePath);

        return sbOut.ToString();
    }

    /// <summary>
    /// Returns the value of the specified setting.
    /// </summary>
    /// <param name="Section">Section name containing setting to read.</param>
    /// <param name="Key">Setting name to read value from.</param>
    /// <param name="FilePath">Filepath to the INI file.</param>
    public static string ReadSetting(string SectionName, string SettingName, string FilePath)
    {
        StringBuilder sbOut = new StringBuilder(500);
        GetPrivateProfileString(SectionName, SettingName, "", sbOut, 500, FilePath);

        return sbOut.ToString();
    }
}
