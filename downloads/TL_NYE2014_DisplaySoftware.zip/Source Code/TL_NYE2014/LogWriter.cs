using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Windows.Forms;

public class LogWriter
{
    private string logDirectory;
    private FileNameStyles style;
    private string logType;
    private string extension;

    public enum FileNameStyles
    {
        LogTypeMMDDYY,
        LogTypeMMDD,
        MMDDYY,
        MMDD
    }

    public LogWriter(FileNameStyles Style, string LogType, string FileExtension)
    {
        DirectoryCheck(Application.StartupPath + "\\Logs\\");

        logDirectory = Application.StartupPath + "\\Logs\\";
        style = Style;
        logType = LogType;
        extension = FileExtension;
    }

    public LogWriter(string LogDirectory, FileNameStyles Style, string LogType, string FileExtension)
    {
        logDirectory = LogDirectory;
        style = Style;
        logType = LogType;
        extension = FileExtension;
    }

    private string LogFileName
    {
        get
        {
            switch (style)
            {
                case FileNameStyles.LogTypeMMDD:
                    {
                        return String.Concat(logType, String.Format("{0:MMdd}", DateTime.Now), extension);
                    }
                case FileNameStyles.LogTypeMMDDYY:
                    {
                        return String.Concat(logType, String.Format("{0:MMddyy}", DateTime.Now), extension);
                    }
                case FileNameStyles.MMDD:
                    {
                        return String.Concat(String.Format("{0:MMdd}", DateTime.Now), extension);
                    }
                case FileNameStyles.MMDDYY:
                    {
                        return String.Concat(String.Format("{0:MMddyy}", DateTime.Now), extension);
                    }
                default:
                    return String.Concat("UndefinedStyle", extension);
            }
        }
    }

    /// <summary>
    /// Checks if a directory exists and creates it if necessary.
    /// </summary>
    /// <param name="FileDirectory">Directory path to check.</param>
    /// <returns>True if directory exists or was created. False if cannot create directory.</returns>
    private bool DirectoryCheck(string FileDirectory)
    {
        if (!Directory.Exists(FileDirectory))
        {
            try
            {
                Directory.CreateDirectory(FileDirectory);
                return true;
            }
            catch
            {
                return false;
            }
        }
        else
            return true;
    }

    public void Write(string Message, bool IncludeTimeStamp, bool BlankLineAfterMsg)
    {
        StringBuilder sb  = new StringBuilder();
        StreamWriter log;
        string filename = logDirectory + LogFileName;

        if (IncludeTimeStamp)
        {
            sb.Append(String.Format("{0:MM/dd/yy hh:mm:ss tt}", DateTime.Now));
            sb.Append(" | ");
        }

        sb.Append(Message);

        try
        {
            if (!File.Exists(filename))
            {
                log = new StreamWriter(filename);
                log.WriteLine(DateTime.Now);
                log.WriteLine("--------------------------------------------------------------");
                log.WriteLine("     A new " + logType + " log file has been created");
                log.WriteLine("--------------------------------------------------------------");
                log.WriteLine();
            }
            else
            {
                log = File.AppendText(filename);
            }

            log.WriteLine(sb.ToString());
            if (BlankLineAfterMsg)
                log.WriteLine();

            log.Close();
        }
        catch (Exception ex)
        {
            //EventLogWriter.WriteEntry(ex, System.Diagnostics.EventLogEntryType.Error, 1984);
            MessageBox.Show(ex.Message, "Error. Log file cannot be written.");
        }
    }

    public void Write(Exception Message, bool IncludeTimeStamp, bool BlankLineAfterMsg)
    {
        StringBuilder sb = new StringBuilder();
        StreamWriter log;
        string filename = logDirectory + LogFileName;

        if (IncludeTimeStamp)
        {
            sb.Append(String.Format("{0:MM/dd/yy hh:mm:ss tt}", DateTime.Now));
            sb.Append(" | ");
        }

        sb.Append("Message: "  + Message.Message + "\r\n\r\n");
        sb.Append("Source: " + Message.Source + "\r\n\r\n");
        sb.Append("StackTrace: " + Message.StackTrace + "\r\n\r\n");

        try
        {
            if (!File.Exists(filename))
            {
                log = new StreamWriter(filename);
                log.WriteLine(DateTime.Now);
                log.WriteLine("--------------------------------------------------------------");
                log.WriteLine("     A new " + logType + " log file has been created");
                log.WriteLine("--------------------------------------------------------------");
                log.WriteLine();
            }
            else
            {
                log = File.AppendText(filename);
            }
;
            log.WriteLine(sb.ToString());
            if (BlankLineAfterMsg)
                log.WriteLine();

            log.Close();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Error: Log file cannot be written.");
        }
    }
}
