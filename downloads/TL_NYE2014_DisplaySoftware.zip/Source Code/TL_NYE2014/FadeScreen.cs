﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace TL_NYE2014
{
    class FadeScreen
    {
        private Texture2D _pixel = null;

        private int _screenWidth = 0;
        private int _screenHeight = 0;

        private bool _fading;
        private bool _needTimeUpdate;
        private int _opacityPerSecond;
        private double _fadeTimeStart;
        private FadeState _fadeState;

        public bool IsFinished = false;
        public float Opacity = 0;
        public Color FadeColor = Color.Black;

        public enum FadeState
        {
            FadeIn,
            FadeOut,
            FadeInOut,
            Idle
        }

        public byte FadeSpeed
        {
            get { return (byte)MathHelper.Clamp(_opacityPerSecond, 0, 255); }
            set { _opacityPerSecond = value; }
        }

        public FadeState CurrentFadeState
        {
            get { return _fadeState; }
            set
            {
                if (value == _fadeState)
                    return;
                else if (value == FadeState.Idle)
                {
                    _fadeState = value;
                    _needTimeUpdate = false;
                    _fading = false;
                }
                else
                {
                    _fadeState = value;
                    _needTimeUpdate = true;
                    _fading = true;
                }
            }
        }

        public FadeScreen(GraphicsDevice graphics)
        {
            _pixel = new Texture2D(graphics, 1, 1);
            _pixel.SetData<Color>(new Color[] { Color.White });

            _screenHeight = graphics.Viewport.Height;
            _screenWidth = graphics.Viewport.Width;

            CurrentFadeState = FadeState.Idle;

            _opacityPerSecond = 200; //default 5 second fade
        }

        public void Update(GameTime gameTime)
        {
            if (_fading && _fadeState != FadeState.Idle)
            {            
                if (_needTimeUpdate)
                {
                    _fadeTimeStart = gameTime.TotalGameTime.TotalSeconds;
                    _needTimeUpdate = false;
                }

                IsFinished = false;

                double elapsedSeconds = gameTime.TotalGameTime.TotalSeconds - _fadeTimeStart;

                if (_fadeState == FadeState.FadeIn || _fadeState == FadeState.FadeInOut)
                    Opacity = (float)(elapsedSeconds * _opacityPerSecond);
                else
                    Opacity = 255 - (float)(elapsedSeconds * _opacityPerSecond);
             
                if (Opacity < 0 || Opacity > 255)
                {
                    if (_fadeState == FadeState.FadeInOut && Opacity > 255)
                    {
                        IsFinished = true;
                        CurrentFadeState = FadeState.FadeOut;
                    }
                    else
                    {
                        IsFinished = true;
                        CurrentFadeState = FadeState.Idle;
                    }
 
                    Opacity = (int)MathHelper.Clamp(Opacity, 0, 255);
                } 
            }
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(_pixel, new Vector2(0, 0), null, new Color(FadeColor.R, FadeColor.G, FadeColor.B, (byte)Opacity), 
                0f, Vector2.Zero, new Vector2(_screenWidth, _screenHeight), SpriteEffects.None, 0);
        }

 
    }
}
