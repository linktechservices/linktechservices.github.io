﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace XNAUtilities
{
    public class GraphicUtilities
    {
        /// <summary>
        /// Helper calculates the destination rectangle
        /// needed to draw a fullscreen sprite.
        /// </summary>
        public static Rectangle FullscreenRectangle(GraphicsDeviceManager graphics)
        {
            Viewport viewport = graphics.GraphicsDevice.Viewport;

            return new Rectangle(0, 0, viewport.Width, viewport.Height);
        }

        /// <summary>
        /// Helper adds newline characters to a string to provide basic word wrapping.
        /// </summary>
        public static string WrapText(SpriteFont spriteFont, string text, float maxLineWidth)
        {
            string[] words = text.Split(' ');

            StringBuilder sb = new StringBuilder();

            float lineWidth = 0f;

            float spaceWidth = spriteFont.MeasureString(" ").X;

            foreach (string word in words)
            {
                Vector2 size = spriteFont.MeasureString(word);

                if (lineWidth + size.X < maxLineWidth)
                {
                    sb.Append(word + " ");
                    lineWidth += size.X + spaceWidth;
                }
                else
                {
                    sb.Append("\n" + word + " ");
                    lineWidth = size.X + spaceWidth;
                }
            }

            return sb.ToString();
        }
    }


    public class MathUtilities
    {
        /// <summary>
        /// Helper computes a value that oscillates over time.
        /// </summary>
        public static float Pulsate(GameTime gameTime, float speed, float min, float max)
        {
            double time = gameTime.TotalGameTime.TotalSeconds * speed;

            return min + ((float)Math.Sin(time) + 1) / 2 * (max - min);
        }

        //public static Vector2 CalculateGravity()
        //{
        //    Vector2 Gravity = new Vector2(0.0f, -9.8f);

        //    Vector2 Acceleration = Gravity;//insert other forces here
        //    Vector2 Position += Speed * DeltaT + 0.5 * Acceleration * DeltaT * DeltaT.
        //    Vector3D Speed+=Acceleration*DeltaT;
        //}
    }
    
}
